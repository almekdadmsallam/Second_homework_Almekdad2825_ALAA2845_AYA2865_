from tkinter import *
from tkinter import ttk
import webbrowser
import subprocess
import os
from tkinter import messagebox
from pygame import mixer
# ............................
# القسم الجيولوجي الخاص بالواجهة العامة

root = Tk()
root.title("my app")
root.geometry('600x513')

# قسم المتغيرات
image = PhotoImage(file="2222.png")
background_label = Label(root, image=image)
background_label.place(x=0, y=0, relheight=1, relwidth=1)

# قسم توابع العمل


def play_music():
    mixer.init()
    mixer.music.load("vv.mp3")
    mixer.music.play()


def show_warning():
    messagebox.showwarning(
        "تحذير", "مشروع الكشف عن السيارات بإشراف الدكتور مهند عيسى)")


def stop_music():
    mixer.music.stop()


def myfuncall():
    webbrowser.open("https://wa.me/963943436172")


def myfuncall1():
    webbrowser.open("https://wa.me/963983106482")


def myfuncall2():
    webbrowser.open("https://wa.me/963930685184")


def myfuncall3():
    webbrowser.open("https://wa.me/963935414465")


def run_speed_file():
    subprocess.run(["python", "main.py"])


def open_screenshot():
    os.startfile("screenshot.png")

# انشاء الأزرار


button = Button(root, text="Run the program",
                command=run_speed_file, fg='white', bg='#625B5B', padx=10, pady=3, font='helvatica 20 bold', borderwidth=0)
button.pack()

mybottonss = Button(root, text='call DR, MOHANNAD ISSA on whatsapp', fg='red',
                    bg='#827B5B', font='helvatica 20 bold', padx=5, pady=5, command=myfuncall, borderwidth=0)
mybottonss.pack()
mybottonss = Button(root, text='call ALMEKDAD on whatsapp', fg='yellow',
                    bg='#825B5B', font='helvatica 20 bold', padx=5, pady=5, command=myfuncall1, borderwidth=0)
mybottonss.pack()
mybottonss = Button(root, text='call ALAA on whatsapp', fg='blue',
                    bg='#826B5B', font='helvatica 20 bold', padx=5, pady=5, command=myfuncall2, borderwidth=0)
mybottonss.pack()
mybottonss = Button(root, text='call AYA on whatsapp', fg='green',
                    bg='#829B5B', font='helvatica 20 bold', padx=5, pady=5, command=myfuncall3, borderwidth=0)
mybottonss.pack()


mybotton1 = Button(root, text='Exit', relief="solid", width=10, height=0, fg='Gold', bg='#207B5B',
                   font='helvatica 20 bold', padx=3, pady=3, command=exit, borderwidth=0)


button = Button(root, text="أطلق إنذار تأهب حادث طريق", command=play_music)
button_stop = Button(root, text="أوقف الإنذار", command=stop_music)
buttona = Button(root, text="لم أفهم ماذا أفعل", command=show_warning)

# إظهار الأزرار

buttona.pack()

mybotton1.pack()
button.pack(side=LEFT)
button_stop.pack(side=RIGHT)
root.mainloop()
