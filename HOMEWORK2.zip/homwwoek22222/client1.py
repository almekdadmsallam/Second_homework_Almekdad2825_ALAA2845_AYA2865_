import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('localhost', 12345))

welcome_msg = client.recv(1024).decode()
print(welcome_msg)
account_number = input("Enter your account number: ")
client.send(account_number.encode())

auth_status = client.recv(1024).decode()
print(auth_status)
option = input("Select an option (1: check balance, 2: Deposit money, 3: Withdraw money): ")
client.send(option.encode())

if option == '1':
    balance_msg = client.recv(1024).decode()
    print(balance_msg)
elif option in ['2', '3']:
    amount = input("Enter amount of money: ")
    client.send(amount.encode())
    operation_status = client.recv(1024).decode()
    print(operation_status)

client.close()
