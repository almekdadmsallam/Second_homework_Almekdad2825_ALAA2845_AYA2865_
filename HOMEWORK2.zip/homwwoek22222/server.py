import socket
import threading

bank_accounts = {
    '2825': 20000,
    '2845': 40000,
    '2865': 60000,
}

def handle_client(client_socket, client_address):
    client_socket.send(b"Welcome to Bank ATM Application , enter your account number : ")
    account_number = client_socket.recv(1024).decode().strip()

    if account_number not in bank_accounts:
        client_socket.send(b"Account number not in our ATM. SORRY, YOU ARE ABOUT TO GO ):")
        client_socket.close()
        return

    client_socket.send(b"Authentication successful. Select a number from options: 1. Check Balance 2. Deposit 3. Withdraw")
    option = client_socket.recv(1024).decode().strip()

    if option == '1':
        balance = bank_accounts[account_number]
        client_socket.send(f"Your current balance is: {balance}".encode())
    elif option == '2':
        amount = int(client_socket.recv(1024).decode().strip())
        bank_accounts[account_number] += amount
        client_socket.send(b"Deposit successful, Have a good day")
    elif option == '3':
        amount = int(client_socket.recv(1024).decode().strip())
        if amount <= bank_accounts[account_number]:
            bank_accounts[account_number] -= amount
            client_socket.send(b"Withdrawal successful, Have a good day")
        else:
            client_socket.send(b"In real life, we can't take money more than we have,  SORRY, YOU ARE ABOUT TO GO ): ")

    client_socket.close()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('localhost', 12345))
server.listen(5)

print("Server is running. Listening for connections...")

while True:
    client_socket, client_address = server.accept()
    print(f"Connection from {client_address}")

    client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
    client_thread.start()
